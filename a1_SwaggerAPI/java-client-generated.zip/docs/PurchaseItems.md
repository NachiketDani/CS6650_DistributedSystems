# PurchaseItems

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**itemID** | **String** |  |  [optional]
**numberOfItems** | **Integer** |  |  [optional]
